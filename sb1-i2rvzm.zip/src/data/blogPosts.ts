export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  category: string;
  date: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: "building-muscle",
    title: "10 Essential Tips for Building Muscle",
    excerpt: "Learn the fundamental principles of muscle growth and how to optimize your training routine.",
    content: `Building muscle effectively requires a combination of proper training, nutrition, and recovery. Here are 10 essential tips to help you maximize your muscle growth:

1. Progressive Overload
Gradually increase the weight, frequency, or repetitions in your training routine.

2. Compound Exercises
Focus on multi-joint movements like squats, deadlifts, and bench presses.

3. Proper Form
Maintain correct technique to target the right muscles and prevent injury.

4. Adequate Protein Intake
Consume 1.6-2.2g of protein per kg of body weight daily.

5. Caloric Surplus
Eat more calories than you burn to provide energy for muscle growth.

6. Rest and Recovery
Allow 48 hours between training the same muscle groups.

7. Sleep Quality
Aim for 7-9 hours of quality sleep per night.

8. Hydration
Drink plenty of water throughout the day.

9. Consistency
Stick to your training program for at least 8-12 weeks.

10. Track Progress
Keep a workout log to monitor your improvements.`,
    image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&q=80",
    category: "Training",
    date: "2024-03-15"
  },
  {
    id: "post-workout-nutrition",
    title: "The Ultimate Guide to Post-Workout Nutrition",
    excerpt: "Discover what to eat after your workouts to maximize recovery and results.",
    content: `Proper post-workout nutrition is crucial for recovery and muscle growth. Here's your comprehensive guide:

Timing Matters
Consume nutrients within 30 minutes after your workout.

Protein Requirements
Include 20-40g of high-quality protein to support muscle repair.

Carbohydrates
Replenish glycogen stores with fast-digesting carbs.

Hydration
Replace fluids lost during exercise with water and electrolytes.

Best Post-Workout Meals
1. Protein shake with banana
2. Greek yogurt with berries
3. Chicken with rice
4. Salmon with sweet potato

Recovery Benefits
- Reduces muscle soreness
- Restores energy levels
- Supports muscle growth
- Improves recovery time`,
    image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80",
    category: "Nutrition",
    date: "2024-03-14"
  },
  {
    id: "staying-motivated",
    title: "How to Stay Motivated in Your Fitness Journey",
    excerpt: "Tips and strategies to maintain your motivation and achieve your fitness goals.",
    content: `Staying motivated on your fitness journey can be challenging, but these strategies will help you maintain focus and dedication:

Set SMART Goals
- Specific
- Measurable
- Achievable
- Relevant
- Time-bound

Track Your Progress
Keep a workout journal and take progress photos.

Find Your Why
Identify deep, meaningful reasons for your fitness journey.

Build a Support System
- Join fitness communities
- Find a workout buddy
- Share goals with friends and family

Celebrate Small Wins
Acknowledge progress, no matter how small.

Mix Up Your Routine
Try new exercises and activities to prevent boredom.

Visualize Success
Imagine achieving your fitness goals daily.

Stay Consistent
Focus on building sustainable habits.`,
    image: "https://images.unsplash.com/photo-1548690312-e3b507d8c110?auto=format&fit=crop&q=80",
    category: "Motivation",
    date: "2024-03-13"
  }
];