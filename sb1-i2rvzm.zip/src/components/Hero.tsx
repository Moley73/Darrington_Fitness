import { ArrowRight } from 'lucide-react';

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="home" className="relative min-h-screen flex items-center">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80"
          className="w-full h-full object-cover"
          alt="Fitness background"
        />
        <div className="absolute inset-0 bg-black/70" />
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="lg:w-2/3">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Transform Your Life With <span className="text-red-500">Darrington Fitness</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Expert personal training, customized workout plans, and nutritional guidance
            to help you achieve your fitness goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={() => scrollToSection('contact')}
              className="inline-flex items-center justify-center px-8 py-3 text-lg font-medium text-white bg-red-500 rounded-md hover:bg-red-600 transition-colors"
            >
              Start Your Journey
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            <button
              onClick={() => scrollToSection('services')}
              className="inline-flex items-center justify-center px-8 py-3 text-lg font-medium text-white border-2 border-white rounded-md hover:bg-white hover:text-black transition-colors"
            >
              View Services
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}