import { ArrowLeft } from 'lucide-react';
import { useParams, Link } from 'react-router-dom';
import { blogPosts } from '../data/blogPosts';

export default function BlogPost() {
  const { id } = useParams();
  const post = blogPosts.find(post => post.id === id);

  if (!post) {
    return (
      <div className="min-h-screen pt-20 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-3xl font-bold text-gray-900">Post not found</h1>
          <Link to="/" className="text-red-500 hover:text-red-600 inline-flex items-center mt-4">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 bg-gray-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Link to="/" className="text-red-500 hover:text-red-600 inline-flex items-center mb-8">
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </Link>
        
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-64 object-cover rounded-lg mb-8"
        />
        
        <div className="prose prose-lg max-w-none">
          <span className="text-sm text-red-500 font-semibold">{post.category}</span>
          <h1 className="text-4xl font-bold text-gray-900 mt-2 mb-4">{post.title}</h1>
          <p className="text-gray-600 mb-8">{post.date}</p>
          
          {post.content.split('\n\n').map((paragraph, index) => (
            <p key={index} className="text-gray-700 mb-4">
              {paragraph}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
}