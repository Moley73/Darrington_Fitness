import { Instagram, Facebook, Twitter } from 'lucide-react';

export default function Trainers() {
  const trainers = [
    {
      name: "Brian Darrington",
      role: "Head Trainer & Founder",
      image: "https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&q=80",
      bio: "With over 15 years of experience in personal training and fitness coaching, Brian specializes in strength training and athletic performance. His passion for fitness has helped hundreds of clients achieve their goals.",
      socials: {
        instagram: "#",
        facebook: "#",
        twitter: "#"
      }
    },
    {
      name: "Louise Darrington",
      role: "Nutrition Specialist & Trainer",
      image: "https://images.unsplash.com/photo-1609899464726-935255b84ac1?auto=format&fit=crop&q=80",
      bio: "Louise combines her expertise in nutrition and fitness to create holistic training programs. She specializes in weight management and women's fitness, helping clients build sustainable healthy habits.",
      socials: {
        instagram: "#",
        facebook: "#",
        twitter: "#"
      }
    }
  ];

  return (
    <div id="trainers" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Meet Our Trainers</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Expert trainers dedicated to helping you achieve your fitness goals
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {trainers.map((trainer, index) => (
            <div key={index} className="bg-gray-50 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
              <div className="aspect-w-3 aspect-h-4">
                <img
                  src={trainer.image}
                  alt={trainer.name}
                  className="w-full h-[400px] object-cover"
                />
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{trainer.name}</h3>
                <p className="text-red-500 font-semibold mb-4">{trainer.role}</p>
                <p className="text-gray-600 mb-6">{trainer.bio}</p>
                <div className="flex space-x-4">
                  <a href={trainer.socials.instagram} className="text-gray-600 hover:text-red-500 transition-colors">
                    <Instagram className="h-6 w-6" />
                  </a>
                  <a href={trainer.socials.facebook} className="text-gray-600 hover:text-red-500 transition-colors">
                    <Facebook className="h-6 w-6" />
                  </a>
                  <a href={trainer.socials.twitter} className="text-gray-600 hover:text-red-500 transition-colors">
                    <Twitter className="h-6 w-6" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}