import { Dumbbell, Users, Clock, BookOpen } from 'lucide-react';

export default function Services() {
  const services = [
    {
      icon: <Dumbbell className="h-8 w-8 text-red-500" />,
      title: "Personal Training",
      description: "One-on-one customized training sessions tailored to your specific goals and fitness level."
    },
    {
      icon: <Users className="h-8 w-8 text-red-500" />,
      title: "Group Classes",
      description: "High-energy group workouts that combine strength training and cardio for maximum results."
    },
    {
      icon: <Clock className="h-8 w-8 text-red-500" />,
      title: "Flexible Scheduling",
      description: "Early morning to late evening sessions available to fit your busy lifestyle."
    },
    {
      icon: <BookOpen className="h-8 w-8 text-red-500" />,
      title: "Nutrition Planning",
      description: "Expert guidance on nutrition to complement your fitness journey and maximize results."
    }
  ];

  return (
    <div id="services" className="py-24 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Transform your body and mind with our comprehensive fitness services
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <div className="mb-4">{service.icon}</div>
              <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
              <p className="text-gray-400">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}